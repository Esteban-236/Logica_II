package servicios;

import modelos.Documento;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DocumentoServicio {

    private static final String[] encabezados = new String[]{
            "#", "Primer Apellido", "Segundo Apellido", "Nombres", "Documento"
    };

    private static List<Documento> documentos = new ArrayList<>();

    public static String[] getEncabezados() {
        return encabezados.clone();
    }

    public static void cargar(String nombreArchivo) {
        documentos = new ArrayList<>();
        try {
            java.nio.file.Path principal = Paths.get(nombreArchivo);
            cargarArchivo(principal, true);
            for (int parte = 2; parte <= 6; parte++) {
                String rutaParte = nombreArchivo.substring(0, nombreArchivo.length() - 4)
                        + String.format("_%02d.csv", parte);
                java.nio.file.Path archivoParte = Paths.get(rutaParte);
                if (Files.exists(archivoParte)) cargarArchivo(archivoParte, false);
            }
            System.out.println("Documentos cargados: " + documentos.size());
        } catch (Exception e) {
            documentos = new ArrayList<>();
            throw new IllegalStateException("No fue posible cargar " + nombreArchivo, e);
        }
    }

    private static void cargarArchivo(java.nio.file.Path ruta, boolean omitirEncabezado) throws java.io.IOException {
        try (Stream<String> lineas = Files.lines(ruta, StandardCharsets.UTF_8)) {
            Stream<String> contenido = omitirEncabezado ? lineas.skip(1) : lineas;
            contenido.filter(linea -> linea != null && !linea.isBlank())
                    .map(linea -> linea.split(";", -1))
                    .filter(textos -> textos.length >= 4)
                    .map(textos -> new Documento(textos[0].trim(), textos[1].trim(),
                            textos[2].trim(), textos[3].trim()))
                    .forEach(documentos::add);
        }
    }

    public static String[][] getDatosDocumentos() {
        String[][] datos = new String[documentos.size()][encabezados.length];
        for (int i = 0; i < documentos.size(); i++) {
            Documento documento = documentos.get(i);
            datos[i][0] = String.valueOf(i + 1);
            datos[i][1] = documento.getApellido1();
            datos[i][2] = documento.getApellido2();
            datos[i][3] = documento.getNombre();
            datos[i][4] = documento.getDocumento();
        }
        return datos;
    }

    private static boolean esMayor(Documento dI, Documento dJ, int criterio) {
        int comparacion;
        if (criterio == 0) {
            // Primero Nombre Completo y luego Tipo de Documento.
            comparacion = dI.getNombreCompleto().compareToIgnoreCase(dJ.getNombreCompleto());
            if (comparacion == 0) {
                comparacion = dI.getDocumento().compareToIgnoreCase(dJ.getDocumento());
            }
        } else {
            // Primero Tipo de Documento y luego Nombre Completo.
            comparacion = dI.getDocumento().compareToIgnoreCase(dJ.getDocumento());
            if (comparacion == 0) {
                comparacion = dI.getNombreCompleto().compareToIgnoreCase(dJ.getNombreCompleto());
            }
        }
        return comparacion > 0;
    }

    private static void intercambiar(int origen, int destino) {
        Documento temporal = documentos.get(origen);
        documentos.set(origen, documentos.get(destino));
        documentos.set(destino, temporal);
    }

    private static String iniciarMedicion() {
        CronometroServicio.iniciarCronometro();
        return "";
    }

    private static String terminarMedicion() {
        CronometroServicio.detenerCronometro();
        return CronometroServicio.getTextoTiempoCronometro();
    }

    // Ordenamiento por intercambio, siguiendo el procedimiento del taller.
    public static String ordenarBurbuja(int criterio) {
        iniciarMedicion();
        for (int i = 0; i < documentos.size() - 1; i++) {
            for (int j = i + 1; j < documentos.size(); j++) {
                if (esMayor(documentos.get(i), documentos.get(j), criterio)) {
                    intercambiar(i, j);
                }
            }
        }
        return terminarMedicion();
    }

    public static String ordenarRapido(int criterio) {
        iniciarMedicion();
        _ordenarRapido(0, documentos.size() - 1, criterio);
        return terminarMedicion();
    }

    private static void _ordenarRapido(int inicio, int fin, int criterio) {
        if (inicio >= fin) {
            return;
        }
        int posicionPivote = ubicarPivote(inicio, fin, criterio);
        _ordenarRapido(inicio, posicionPivote - 1, criterio);
        _ordenarRapido(posicionPivote + 1, fin, criterio);
    }

    private static int ubicarPivote(int inicio, int fin, int criterio) {
        Documento pivote = documentos.get(inicio);
        int posicionPivote = inicio;
        for (int i = inicio + 1; i <= fin; i++) {
            if (esMayor(pivote, documentos.get(i), criterio)) {
                posicionPivote++;
                if (i != posicionPivote) {
                    intercambiar(i, posicionPivote);
                }
            }
        }
        if (inicio != posicionPivote) {
            intercambiar(inicio, posicionPivote);
        }
        return posicionPivote;
    }

    // Inserción directa: desplaza los elementos mayores y ubica la clave.
    public static String ordenarInsercion(int criterio) {
        iniciarMedicion();
        for (int i = 1; i < documentos.size(); i++) {
            Documento clave = documentos.get(i);
            int j = i - 1;
            while (j >= 0 && esMayor(documentos.get(j), clave, criterio)) {
                documentos.set(j + 1, documentos.get(j));
                j--;
            }
            documentos.set(j + 1, clave);
        }
        return terminarMedicion();
    }

    // Selección directa: busca el menor elemento de la parte no ordenada.
    public static String ordenarSeleccion(int criterio) {
        iniciarMedicion();
        for (int i = 0; i < documentos.size() - 1; i++) {
            int posicionMenor = i;
            for (int j = i + 1; j < documentos.size(); j++) {
                if (esMayor(documentos.get(posicionMenor), documentos.get(j), criterio)) {
                    posicionMenor = j;
                }
            }
            if (posicionMenor != i) {
                intercambiar(i, posicionMenor);
            }
        }
        return terminarMedicion();
    }

    // Mezcla (Merge Sort): divide el arreglo, ordena cada mitad y las mezcla.
    public static String ordenarMezcla(int criterio) {
        iniciarMedicion();
        if (documentos.size() > 1) {
            Documento[] arreglo = documentos.toArray(new Documento[0]);
            Documento[] auxiliar = new Documento[arreglo.length];
            mezclaRec(arreglo, auxiliar, 0, arreglo.length - 1, criterio);
            for (int i = 0; i < arreglo.length; i++) {
                documentos.set(i, arreglo[i]);
            }
        }
        return terminarMedicion();
    }

    private static void mezclaRec(Documento[] arreglo, Documento[] auxiliar,
                                  int inicio, int fin, int criterio) {
        if (inicio >= fin) {
            return;
        }
        int medio = inicio + (fin - inicio) / 2;
        mezclaRec(arreglo, auxiliar, inicio, medio, criterio);
        mezclaRec(arreglo, auxiliar, medio + 1, fin, criterio);
        merge(arreglo, auxiliar, inicio, medio, fin, criterio);
    }

    private static void merge(Documento[] arreglo, Documento[] auxiliar,
                              int inicio, int medio, int fin, int criterio) {
        System.arraycopy(arreglo, inicio, auxiliar, inicio, fin - inicio + 1);
        int i = inicio;
        int j = medio + 1;
        int k = inicio;

        while (i <= medio && j <= fin) {
            // Si el elemento izquierdo no es mayor, se conserva primero.
            if (!esMayor(auxiliar[i], auxiliar[j], criterio)) {
                arreglo[k++] = auxiliar[i++];
            } else {
                arreglo[k++] = auxiliar[j++];
            }
        }
        while (i <= medio) {
            arreglo[k++] = auxiliar[i++];
        }
        while (j <= fin) {
            arreglo[k++] = auxiliar[j++];
        }
    }
}
