# Gestor de Rutas – Medellín

Aplicación Java (Swing) para gestionar una ruta de paradas turísticas sobre un mapa de OpenStreetMap.
Las paradas se mantienen en memoria en una **lista ligada** (`ListaParadas`) y se guardan/cargan en un **archivo JSON**.

## Cómo ejecutarla

Requiere **Java 17 o superior** y **Maven**, con conexión a internet (para descargar las dependencias y los mapas).

```bash
mvn package
java -jar target/rutas-medellin.jar
```

Ejecútalo desde la carpeta del proyecto: el selector de archivos abre por defecto la carpeta `rutas/`, donde viene un ejemplo (`ruta_ejemplo.json`).

Si prefieres un IDE (NetBeans, IntelliJ, Eclipse), abre la carpeta como proyecto Maven, o copia `src/main/java` a tu proyecto y agrega las librerías `jxmapviewer2` (2.8) y `jackson-databind` (2.17.x).

## Pantalla

La interfaz sigue el diseño de referencia del enunciado:

- **Encabezado "Mapa"** y, a la izquierda, el panel de rutas; a la derecha, el mapa de OpenStreetMap.
- **Tres rutas** (botones de bus verde, azul y rojo). Cada una es su propia lista ligada de paradas; las operaciones actúan sobre la ruta activa.
- **Barra de color** con el nombre de la ruta y un interruptor para mostrarla u ocultarla en el mapa.
- **Lista numerada** de las paradas (círculo con el número, nombre en mayúsculas).
- **Mapa** con marcadores numerados, la línea que une las paradas en orden y los pines amarillos de **Puntos de interés** (se activan/desactivan con la pestaña de la esquina superior derecha).

## Operaciones

| Operación | Cómo se hace |
|---|---|
| Agregar parada | Botón **Agregar Parada**: abre el formulario y la añade al final de la ruta activa |
| Seleccionar parada | Clic en la parada en la lista o sobre su marcador en el mapa; el mapa se centra en ella |
| Modificar parada | Seleccionarla y pulsar **Modificar Parada** |
| Eliminar parada | Seleccionarla y pulsar **Eliminar Parada** (pide confirmación) |
| Mostrar las paradas | La lista numerada del panel izquierdo y los marcadores del mapa |
| Guardar ruta | **Guardar Ruta**: escribe la ruta activa en un archivo `.json` |
| Cargar ruta guardada | **Cargar Ruta**: lee un `.json` y reconstruye la lista ligada de la ruta activa |
| Distancia total aproximada | **Calcular Distancia**: suma las distancias entre paradas consecutivas (Haversine, en km) |

Al iniciar se cargan `rutas/ruta_medellin_1.json`, `ruta_medellin_2.json` y `ruta_medellin_3.json` en las rutas 1, 2 y 3 (si la 1 no existe se usa `ruta_ejemplo.json`). Cada punto de interés muestra su nombre resaltado encima del pin. Los puntos de interés son solo una referencia visual (coordenadas aproximadas) y no se guardan en el JSON.

## Datos de cada parada

- Nombre (obligatorio)
- Latitud y longitud (deben estar en el área de Medellín: lat 6.0–6.5, lon −75.8 a −75.3)
- Tiempo estimado de llegada (`HH:mm`, por ejemplo `08:30`)
- Descripción (opcional)

## Formato del JSON

```json
{
  "nombre": "Ruta Turística Medellín",
  "paradas": [
    {
      "nombre": "Parque Berrío",
      "latitud": 6.2518,
      "longitud": -75.5688,
      "horaEstimada": "08:00",
      "descripcion": "Centro histórico de la ciudad"
    }
  ]
}
```

## Estructura

```
src/main/java/
├── App.java
├── controladores/MapaRutaControlador.java   lógica: 3 rutas, botones, selección
├── modelos/
│   ├── Parada.java                          datos de una parada (con validaciones)
│   ├── NodoParada.java                      nodo de la lista ligada
│   ├── ListaParadas.java                    lista ligada + distancia
│   ├── RutaArchivo.java                     lo que se guarda en el JSON
│   └── PuntoInteres.java                    pines amarillos de referencia
├── vistas/
│   ├── MapaRutaVista.java                   ventana: panel de rutas, lista y mapa
│   ├── PintorRutas.java                     dibuja líneas, marcadores numerados y pines
│   ├── Marcador.java                        parada dibujada en el mapa
│   ├── FormularioParada.java                diálogo para agregar/modificar
│   ├── Estilo.java                          colores, fuentes y dibujo del pin
│   └── BotonRuta / Interruptor / ChipPuntos / BotonAccion   componentes visuales
└── servicios/ArchivoServicio.java           leer/escribir JSON y elegir archivo
rutas/ruta_medellin_1/2/3.json               las tres rutas para comparar
rutas/ruta_ejemplo.json                      ruta de ejemplo original
```

## Si el mapa sale en blanco

- Usa **jxmapviewer2 2.6** (la que envió el profesor). Las clases piden también `commons-logging-1.2.jar` y `slf4j-api-1.7.7.jar`. Con Maven se descargan solas; si trabajas sin Maven (NetBeans/Eclipse con librerías manuales), agrega los tres `.jar` de la carpeta `lib/` al proyecto.
- OpenStreetMap solo responde por **HTTPS** y la versión 2.6 usa `http://` por defecto, por eso `MapaRutaVista` crea `new OSMTileFactoryInfo("OpenStreetMap", "https://tile.openstreetmap.org")`.
- Necesita internet. Si la red bloquea `tile.openstreetmap.org`, el mapa también queda en blanco.
