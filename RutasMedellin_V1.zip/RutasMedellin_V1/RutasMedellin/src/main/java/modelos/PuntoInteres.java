package modelos;

import java.util.List;

/** Lugar de interés que se dibuja como pin amarillo en el mapa (solo referencia visual). */
public class PuntoInteres {

    private final String nombre;
    private final double latitud;
    private final double longitud;

    public PuntoInteres(String nombre, double latitud, double longitud) {
        this.nombre = nombre;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public String getNombre()   { return nombre; }
    public double getLatitud()  { return latitud; }
    public double getLongitud() { return longitud; }

    /** Algunos lugares conocidos de Medellín (coordenadas aproximadas). */
    public static List<PuntoInteres> catalogoMedellin() {
        return List.of(
                new PuntoInteres("Museo de Antioquia", 6.2523, -75.5690),
                new PuntoInteres("Catedral Metropolitana", 6.2528, -75.5675),
                new PuntoInteres("Parque San Antonio", 6.2467, -75.5686),
                new PuntoInteres("Parque Explora", 6.2713, -75.5655),
                new PuntoInteres("Universidad de Antioquia", 6.2680, -75.5686),
                new PuntoInteres("Cerro El Volador", 6.2745, -75.5815),
                new PuntoInteres("Plaza Mayor", 6.2421, -75.5749),
                new PuntoInteres("Parque de El Poblado", 6.2086, -75.5708),
                new PuntoInteres("Museo El Castillo", 6.1962, -75.5575));
    }
}
