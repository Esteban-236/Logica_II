package modelos;

import java.util.List;

// Estructura que se guarda tal cual en el archivo JSON
public class RutaArchivo {
    public String nombre;
    public List<Parada> paradas;

    public RutaArchivo() {
    }

    public RutaArchivo(String nombre, List<Parada> paradas) {
        this.nombre = nombre;
        this.paradas = paradas;
    }
}
