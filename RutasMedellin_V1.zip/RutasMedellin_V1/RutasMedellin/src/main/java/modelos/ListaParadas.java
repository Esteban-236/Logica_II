package modelos;

import java.util.ArrayList;
import java.util.List;

public class ListaParadas {

    private NodoParada cabeza;
    private int tamanio;
    private String nombreRuta;

    public ListaParadas(String nombreRuta) {
        this.nombreRuta = nombreRuta;
        this.cabeza = null;
        this.tamanio = 0;
    }

    // ================= OPERACIONES =================

    /** Agregar parada al final de la ruta */
    public void agregar(Parada p) {
        NodoParada nuevo = new NodoParada(p);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoParada aux = cabeza;
            while (aux.siguiente != null) {
                aux = aux.siguiente;
            }
            aux.siguiente = nuevo;
        }
        tamanio++;
    }

    /** Seleccionar (obtener) una parada por su posición */
    public Parada obtener(int indice) {
        validarIndice(indice);
        return nodoEn(indice).dato;
    }

    /** Modificar una parada existente */
    public void modificar(int indice, Parada nueva) {
        validarIndice(indice);
        nodoEn(indice).dato = nueva;
    }

    /** Eliminar una parada y devolverla */
    public Parada eliminar(int indice) {
        validarIndice(indice);

        Parada eliminada;
        if (indice == 0) {
            eliminada = cabeza.dato;
            cabeza = cabeza.siguiente;
        } else {
            NodoParada anterior = nodoEn(indice - 1);
            eliminada = anterior.siguiente.dato;
            anterior.siguiente = anterior.siguiente.siguiente;
        }
        tamanio--;
        return eliminada;
    }

    /** Devuelve la posición de un objeto dentro de la lista (-1 si no está) */
    public int indiceDe(Parada n) {
        int i = 0;
        for (NodoParada aux = cabeza; aux != null; aux = aux.siguiente, i++) {
            if (aux.dato == n)
                return i;
        }
        return -1;
    }

    public int size()                 { return tamanio; }
    public boolean estaVacia()        { return tamanio == 0; }
    public String getNombreRuta()     { return nombreRuta; }
    public void setNombreRuta(String n) { this.nombreRuta = n; }

    /** Las paradas como List normal (para el árbol, el mapa o el JSON) */
    public List<Parada> aLista() {
        List<Parada> lista = new ArrayList<>();
        for (NodoParada aux = cabeza; aux != null; aux = aux.siguiente) {
            lista.add(aux.dato);
        }
        return lista;
    }

    // ================= DISTANCIA =================

    /** Suma las distancias entre paradas consecutivas, en kilómetros */
    public double calcularDistanciaTotalKm() {
        double total = 0;
        NodoParada aux = cabeza;
        while (aux != null && aux.siguiente != null) {
            total += distanciaHaversine(
                    aux.dato.getLatitud(), aux.dato.getLongitud(),
                    aux.siguiente.dato.getLatitud(), aux.siguiente.dato.getLongitud());
            aux = aux.siguiente;
        }
        return total;
    }

    /** Fórmula de Haversine: distancia aproximada entre dos coordenadas */
    public static double distanciaHaversine(double lat1, double lon1,
                                            double lat2, double lon2) {
        final double RADIO_TIERRA_KM = 6371.0;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return RADIO_TIERRA_KM * c;
    }

    // ================= CONVERSIÓN PARA JSON =================

    /** Convierte la lista ligada al objeto que Jackson guarda */
    public RutaArchivo toRutaArchivo() {
        return new RutaArchivo(nombreRuta, aLista());
    }

    /** Construye una lista ligada a partir de lo leído del JSON */
    public static ListaParadas desdeRutaArchivo(RutaArchivo datos) {
        ListaParadas lista = new ListaParadas(datos.nombre);
        if (datos.paradas != null) {
            for (Parada p : datos.paradas) {
                lista.agregar(p);
            }
        }
        return lista;
    }

    // ================= AUXILIARES =================

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= tamanio)
            throw new IndexOutOfBoundsException("Índice inválido: " + indice);
    }

    private NodoParada nodoEn(int indice) {
        NodoParada aux = cabeza;
        for (int i = 0; i < indice; i++) {
            aux = aux.siguiente;
        }
        return aux;
    }
}
