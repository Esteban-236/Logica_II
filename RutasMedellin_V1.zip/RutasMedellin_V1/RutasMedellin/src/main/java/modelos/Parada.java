package modelos;

import java.util.regex.Pattern;

public class Parada {

    private static final Pattern PATRON_HORA = Pattern.compile("([01]\\d|2[0-3]):[0-5]\\d");

    private String nombre;
    private double latitud;
    private double longitud;
    private String horaEstimada;   // formato HH:mm
    private String descripcion;    // opcional

    // Constructor vacío: lo usa Jackson al leer el JSON
    public Parada() {
    }

    public Parada(String nombre, double latitud, double longitud,
                  String horaEstimada, String descripcion) {
        if (nombre == null || nombre.isBlank())
            throw new IllegalArgumentException("El nombre es obligatorio.");
        if (latitud < 6.0 || latitud > 6.5 || longitud < -75.8 || longitud > -75.3)
            throw new IllegalArgumentException("Las coordenadas no corresponden a Medellín.");
        if (!validarHora(horaEstimada))
            throw new IllegalArgumentException("La hora debe tener formato HH:mm (ej: 08:30).");

        this.nombre = nombre.trim();
        this.latitud = latitud;
        this.longitud = longitud;
        this.horaEstimada = horaEstimada;
        this.descripcion = descripcion == null ? "" : descripcion.trim();
    }

    public static boolean validarHora(String hora) {
        return hora != null && PATRON_HORA.matcher(hora).matches();
    }

    // Getters y setters (Jackson los necesita para leer y escribir el JSON)
    public String getNombre()              { return nombre; }
    public void setNombre(String nombre)   { this.nombre = nombre; }

    public double getLatitud()             { return latitud; }
    public void setLatitud(double lat)     { this.latitud = lat; }

    public double getLongitud()            { return longitud; }
    public void setLongitud(double lon)    { this.longitud = lon; }

    public String getHoraEstimada()        { return horaEstimada; }
    public void setHoraEstimada(String h)  { this.horaEstimada = h; }

    public String getDescripcion()         { return descripcion; }
    public void setDescripcion(String d)   { this.descripcion = d; }

    @Override
    public String toString() {
        return nombre + " (" + horaEstimada + ")";
    }
}
