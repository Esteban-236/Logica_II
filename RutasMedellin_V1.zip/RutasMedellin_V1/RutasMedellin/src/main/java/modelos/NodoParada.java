package modelos;

class NodoParada {
    Parada dato;
    NodoParada siguiente;

    NodoParada(Parada dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}
