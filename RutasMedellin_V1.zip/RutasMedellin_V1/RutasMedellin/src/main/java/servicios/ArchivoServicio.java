package servicios;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.IOException;

/** Lectura y escritura de archivos JSON, y diálogo para elegir el archivo. */
public class ArchivoServicio {

    private static final ObjectMapper MAPPER =
            new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

    /**
     * Abre el selector de archivos. Devuelve la ruta elegida
     * o un texto vacío si el usuario cancela.
     */
    public static String elegirArchivo(boolean guardar) {
        File carpetaRutas = new File("rutas");
        JFileChooser selector = new JFileChooser(
                carpetaRutas.isDirectory() ? carpetaRutas : new File(System.getProperty("user.dir")));
        selector.setFileFilter(new FileNameExtensionFilter("Archivos JSON (*.json)", "json"));

        int resultado = guardar ? selector.showSaveDialog(null) : selector.showOpenDialog(null);
        if (resultado != JFileChooser.APPROVE_OPTION) {
            return "";
        }

        File elegido = selector.getSelectedFile();
        if (guardar) {
            // El controlador agrega ".json" si falta, así que se revisa el nombre final
            File destino = elegido.getName().toLowerCase().endsWith(".json")
                    ? elegido
                    : new File(elegido.getPath() + ".json");
            if (destino.exists()) {
                int op = JOptionPane.showConfirmDialog(null,
                        "El archivo \"" + destino.getName() + "\" ya existe. ¿Reemplazarlo?",
                        "Confirmar", JOptionPane.YES_NO_OPTION);
                if (op != JOptionPane.YES_OPTION) {
                    return "";
                }
            }
        }
        return elegido.getAbsolutePath();
    }

    /** Guarda un objeto como JSON. Devuelve true si se pudo escribir. */
    public static boolean guardarJson(String rutaArchivo, Object datos) {
        try {
            MAPPER.writeValue(new File(rutaArchivo), datos);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Lee un JSON y lo convierte al tipo pedido. Devuelve null si falla. */
    public static <T> T leerJson(String rutaArchivo, TypeReference<T> tipo) {
        try {
            return MAPPER.readValue(new File(rutaArchivo), tipo);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
