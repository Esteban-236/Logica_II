package vistas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Botón redondo de color con un bus, para elegir la ruta (verde, azul o roja). */
public class BotonRuta extends JComponent {

    private final Color color;
    private boolean activo;

    public BotonRuta(Color color, String ayuda, Runnable alHacerClic) {
        this.color = color;
        setPreferredSize(new Dimension(50, 50));
        setToolTipText(ayuda);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                alHacerClic.run();
            }
        });
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.suavizar(g);
        int cx = getWidth() / 2;
        int cy = getHeight() / 2;

        if (activo) {
            g.setColor(color);
            g.setStroke(new BasicStroke(2f));
            g.drawOval(cx - 23, cy - 23, 46, 46);
        }
        int d = activo ? 38 : 42;
        g.setColor(color);
        g.fillOval(cx - d / 2, cy - d / 2, d, d);

        // Bus
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawRoundRect(cx - 9, cy - 11, 18, 19, 6, 6);
        g.drawLine(cx - 9, cy - 3, cx + 9, cy - 3);
        g.fillOval(cx - 6, cy + 2, 4, 4);
        g.fillOval(cx + 2, cy + 2, 4, 4);
        g.drawLine(cx - 5, cy + 8, cx - 5, cy + 11);
        g.drawLine(cx + 5, cy + 8, cx + 5, cy + 11);
        g.dispose();
    }
}
