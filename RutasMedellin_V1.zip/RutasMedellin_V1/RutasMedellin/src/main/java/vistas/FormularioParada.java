package vistas;

import modelos.Parada;

import javax.swing.*;
import java.awt.*;

public class FormularioParada {

    /**
     * Muestra el formulario. Si existente es null, es una parada nueva;
     * si no, los campos se llenan con sus datos.
     * Devuelve la parada creada o null si el usuario cancela.
     */
    public static Parada mostrar(Component padre, Parada existente) {
        JTextField txtNombre = new JTextField(20);
        JTextField txtLat    = new JTextField(10);
        JTextField txtLon    = new JTextField(10);
        JTextField txtHora   = new JTextField(10);
        JTextField txtDesc   = new JTextField(20);

        if (existente != null) {
            txtNombre.setText(existente.getNombre());
            txtLat.setText(String.valueOf(existente.getLatitud()));
            txtLon.setText(String.valueOf(existente.getLongitud()));
            txtHora.setText(existente.getHoraEstimada());
            txtDesc.setText(existente.getDescripcion());
        }

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Nombre:"));
        panel.add(txtNombre);
        panel.add(new JLabel("Latitud (ej: 6.2442):"));
        panel.add(txtLat);
        panel.add(new JLabel("Longitud (ej: -75.5734):"));
        panel.add(txtLon);
        panel.add(new JLabel("Tiempo estimado de llegada (HH:mm):"));
        panel.add(txtHora);
        panel.add(new JLabel("Descripción (opcional):"));
        panel.add(txtDesc);

        String titulo = existente == null ? "Nueva parada" : "Modificar parada";

        while (true) {
            int op = JOptionPane.showConfirmDialog(padre, panel, titulo,
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (op != JOptionPane.OK_OPTION) {
                return null;
            }
            try {
                double lat = Double.parseDouble(txtLat.getText().trim().replace(',', '.'));
                double lon = Double.parseDouble(txtLon.getText().trim().replace(',', '.'));
                return new Parada(txtNombre.getText(), lat, lon,
                        txtHora.getText().trim(), txtDesc.getText());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(padre,
                        "Latitud y longitud deben ser números (ej: 6.2442 y -75.5734).",
                        "Dato inválido", JOptionPane.WARNING_MESSAGE);
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(padre, e.getMessage(),
                        "Dato inválido", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}
