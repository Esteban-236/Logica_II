package vistas;

import org.jxmapviewer.viewer.GeoPosition;

import java.awt.Color;

/** Parada dibujada sobre el mapa: posición, número en la ruta, nombre y color de la ruta. */
public class Marcador {

    private final GeoPosition posicion;
    private final int numero;
    private final String nombre;
    private final Color color;

    public Marcador(GeoPosition posicion, int numero, String nombre, Color color) {
        this.posicion = posicion;
        this.numero = numero;
        this.nombre = nombre;
        this.color = color;
    }

    public GeoPosition getPosicion() { return posicion; }
    public int getNumero()           { return numero; }
    public String getNombre()        { return nombre; }
    public Color getColor()          { return color; }
}
