package vistas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Pestaña blanca "Puntos de interés" que muestra u oculta los pines amarillos del mapa. */
public class ChipPuntos extends JComponent {

    private boolean activo = true;

    public ChipPuntos(Runnable alCambiar) {
        setPreferredSize(new Dimension(170, 32));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setToolTipText("Mostrar u ocultar puntos de interés");
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                activo = !activo;
                repaint();
                alCambiar.run();
            }
        });
    }

    public boolean isActivo() {
        return activo;
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.suavizar(g);
        int w = getWidth(), h = getHeight();

        g.setColor(new Color(0, 0, 0, 40));
        g.fillRoundRect(1, 2, w - 2, h - 2, 8, 8);
        g.setColor(Color.WHITE);
        g.fillRoundRect(0, 0, w - 2, h - 3, 8, 8);

        Estilo.dibujarPin(g, 20, h - 8, 18, activo ? Estilo.AMARILLO : new Color(0xBDBDBD));
        g.setFont(Estilo.fuente(Font.PLAIN, 12.5f));
        g.setColor(activo ? Estilo.TEXTO : Estilo.TEXTO_SUAVE);
        g.drawString("Puntos de interés", 36, h / 2 + 3);
        g.dispose();
    }
}
