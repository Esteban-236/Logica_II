package vistas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Interruptor tipo "toggle" (como el de la barra verde de la referencia). */
public class Interruptor extends JComponent {

    private boolean encendido = true;
    private Color colorEncendido = Estilo.COLORES_RUTA[0];

    public Interruptor(Runnable alCambiar) {
        setPreferredSize(new Dimension(42, 22));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                encendido = !encendido;
                repaint();
                alCambiar.run();
            }
        });
    }

    public void setEncendido(boolean encendido) {
        this.encendido = encendido;
        repaint();
    }

    public boolean isEncendido() {
        return encendido;
    }

    public void setColorEncendido(Color c) {
        this.colorEncendido = c;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.suavizar(g);
        int w = getWidth() - 2, h = getHeight() - 2;

        g.setColor(encendido ? Color.WHITE : new Color(255, 255, 255, 120));
        g.fillRoundRect(1, 1, w, h, h, h);

        int d = h - 6;
        int x = encendido ? w - d - 2 : 5;
        g.setColor(encendido ? colorEncendido : new Color(0x9E9E9E));
        g.fillOval(x, 4, d, d);
        g.dispose();
    }
}
