package vistas;

import modelos.PuntoInteres;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.painter.Painter;
import org.jxmapviewer.viewer.GeoPosition;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Dibuja sobre el mapa: la línea de cada ruta, sus paradas numeradas
 * y los pines amarillos de los puntos de interés.
 */
public class PintorRutas implements Painter<JXMapViewer> {

    /** Una ruta lista para dibujar. */
    public static class RutaDibujo {
        final Color color;
        final boolean visible;
        final List<Marcador> marcadores;

        public RutaDibujo(Color color, boolean visible, List<Marcador> marcadores) {
            this.color = color;
            this.visible = visible;
            this.marcadores = marcadores;
        }
    }

    private List<RutaDibujo> rutas = new ArrayList<>();
    private List<PuntoInteres> puntos = new ArrayList<>();
    private boolean verPuntos = true;
    private int rutaActiva = 0;
    private int seleccion = -1;

    public void setRutas(List<RutaDibujo> rutas, int rutaActiva, int seleccion) {
        this.rutas = rutas;
        this.rutaActiva = rutaActiva;
        this.seleccion = seleccion;
    }

    public void setSeleccion(int seleccion)         { this.seleccion = seleccion; }
    public void setPuntos(List<PuntoInteres> p)     { this.puntos = p; }
    public void setVerPuntos(boolean ver)           { this.verPuntos = ver; }
    public boolean isVerPuntos()                    { return verPuntos; }
    public List<PuntoInteres> getPuntos()           { return puntos; }

    /** Posición de un punto geográfico en coordenadas del componente del mapa. */
    public static Point2D aPantalla(JXMapViewer mapa, GeoPosition pos) {
        Point2D p = mapa.getTileFactory().geoToPixel(pos, mapa.getZoom());
        Rectangle vp = mapa.getViewportBounds();
        return new Point2D.Double(p.getX() - vp.getX(), p.getY() - vp.getY());
    }

    @Override
    public void paint(Graphics2D g0, JXMapViewer mapa, int ancho, int alto) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.suavizar(g);
        Rectangle vp = mapa.getViewportBounds();
        g.translate(-vp.getX(), -vp.getY());

        if (verPuntos) {
            for (PuntoInteres poi : puntos) {
                Point2D p = pixel(mapa, new GeoPosition(poi.getLatitud(), poi.getLongitud()));
                Estilo.dibujarPin(g, p.getX(), p.getY(), 26, Estilo.AMARILLO);
            }
        }

        // Primero las rutas que no están seleccionadas; la activa queda encima
        for (int i = 0; i < rutas.size(); i++) {
            if (i != rutaActiva && rutas.get(i).visible) {
                dibujarRuta(g, mapa, rutas.get(i), false);
            }
        }
        if (rutaActiva >= 0 && rutaActiva < rutas.size() && rutas.get(rutaActiva).visible) {
            dibujarRuta(g, mapa, rutas.get(rutaActiva), true);
        }

        // Nombres de los puntos de interés: van al final para que queden encima de todo
        if (verPuntos) {
            dibujarEtiquetasPuntos(g, mapa);
        }
        g.dispose();
    }

    /**
     * Escribe, resaltado encima de cada pin amarillo, el nombre del punto de interés.
     * Si dos etiquetas se pisan (puntos muy cercanos), la segunda se sube un poco.
     */
    private void dibujarEtiquetasPuntos(Graphics2D g, JXMapViewer mapa) {
        g.setFont(Estilo.fuente(Font.BOLD, 11.5f));
        FontMetrics fm = g.getFontMetrics();
        int h = fm.getHeight() + 4;
        double alturaPin = 26;
        Rectangle area = mapa.getViewportBounds();
        List<Rectangle2D> ocupados = new ArrayList<>();

        for (PuntoInteres poi : puntos) {
            Point2D p = pixel(mapa, new GeoPosition(poi.getLatitud(), poi.getLongitud()));
            int w = fm.stringWidth(poi.getNombre()) + 14;
            double bx = p.getX() - w / 2.0;
            double by = p.getY() - alturaPin - 6 - h;

            // Fuera de la pantalla: no se dibuja
            if (!area.intersects(bx - 20, by - 60, w + 40, h + 120)) continue;

            // Evita encimar etiquetas
            boolean choca = true;
            for (int intentos = 0; choca && intentos < 8; intentos++) {
                choca = false;
                Rectangle2D r = new Rectangle2D.Double(bx, by, w, h);
                for (Rectangle2D o : ocupados) {
                    if (r.intersects(o)) {
                        choca = true;
                        by = o.getMinY() - h - 2;
                        break;
                    }
                }
            }
            ocupados.add(new Rectangle2D.Double(bx, by, w, h));

            int ix = (int) Math.round(bx), iy = (int) Math.round(by);
            // Sombra
            g.setColor(new Color(0, 0, 0, 60));
            g.fillRoundRect(ix + 1, iy + 2, w, h, 10, 10);
            // Fondo amarillo resaltado + borde
            g.setColor(new Color(0xFFD54F));
            g.fillRoundRect(ix, iy, w, h, 10, 10);
            g.setColor(Estilo.AMARILLO);
            g.setStroke(new BasicStroke(1.6f));
            g.drawRoundRect(ix, iy, w, h, 10, 10);
            // Texto
            g.setColor(new Color(0x2B2B2B));
            g.drawString(poi.getNombre(), ix + 7, iy + 2 + fm.getAscent());
        }
    }

    private void dibujarRuta(Graphics2D g, JXMapViewer mapa, RutaDibujo ruta, boolean activa) {
        List<Marcador> ms = ruta.marcadores;
        if (ms.isEmpty()) return;

        // Línea que une las paradas en orden
        if (ms.size() > 1) {
            Path2D.Double linea = new Path2D.Double();
            for (int i = 0; i < ms.size(); i++) {
                Point2D p = pixel(mapa, ms.get(i).getPosicion());
                if (i == 0) linea.moveTo(p.getX(), p.getY());
                else linea.lineTo(p.getX(), p.getY());
            }
            g.setStroke(new BasicStroke(activa ? 8f : 7f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(new Color(255, 255, 255, 190));
            g.draw(linea);
            g.setStroke(new BasicStroke(activa ? 4.5f : 3.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(ruta.color);
            g.draw(linea);
        }

        // Paradas numeradas
        int indiceSel = activa ? seleccion : -1;
        for (int i = 0; i < ms.size(); i++) {
            if (i != indiceSel) dibujarMarcador(g, mapa, ms.get(i), false);
        }
        if (indiceSel >= 0 && indiceSel < ms.size()) {
            dibujarMarcador(g, mapa, ms.get(indiceSel), true);
        }
    }

    private void dibujarMarcador(Graphics2D g, JXMapViewer mapa, Marcador m, boolean seleccionado) {
        Point2D p = pixel(mapa, m.getPosicion());
        double x = p.getX(), y = p.getY();
        double d = seleccionado ? 28 : 22;

        if (seleccionado) {
            Color c = m.getColor();
            g.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), 70));
            g.fill(new Ellipse2D.Double(x - 20, y - 20, 40, 40));
        }
        g.setColor(new Color(0, 0, 0, 55));
        g.fill(new Ellipse2D.Double(x - d / 2 + 1, y - d / 2 + 2, d, d));
        g.setColor(Color.WHITE);
        g.fill(new Ellipse2D.Double(x - d / 2 - 2, y - d / 2 - 2, d + 4, d + 4));
        g.setColor(m.getColor());
        g.fill(new Ellipse2D.Double(x - d / 2, y - d / 2, d, d));

        g.setColor(Color.WHITE);
        g.setFont(Estilo.fuente(Font.BOLD, seleccionado ? 13f : 11.5f));
        Estilo.textoCentrado(g, String.valueOf(m.getNumero()), x, y);

        if (seleccionado) {
            g.setFont(Estilo.fuente(Font.BOLD, 12f));
            FontMetrics fm = g.getFontMetrics();
            int w = fm.stringWidth(m.getNombre());
            int h = fm.getHeight();
            int bx = (int) (x - w / 2.0 - 7);
            int by = (int) (y - d / 2 - 12 - h);
            g.setColor(new Color(0, 0, 0, 45));
            g.fillRoundRect(bx + 1, by + 2, w + 14, h + 4, 8, 8);
            g.setColor(Color.WHITE);
            g.fillRoundRect(bx, by, w + 14, h + 4, 8, 8);
            g.setColor(Estilo.TEXTO);
            g.drawString(m.getNombre(), bx + 7, by + fm.getAscent() + 2);
        }
    }

    private static Point2D pixel(JXMapViewer mapa, GeoPosition pos) {
        return mapa.getTileFactory().geoToPixel(pos, mapa.getZoom());
    }
}
