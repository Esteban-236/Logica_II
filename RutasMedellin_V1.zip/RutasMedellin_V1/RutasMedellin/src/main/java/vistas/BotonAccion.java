package vistas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Botón plano y redondeado para las operaciones (agregar, modificar, etc.). */
public class BotonAccion extends JButton {

    private boolean encima;

    public BotonAccion(String texto) {
        super(texto);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setOpaque(false);
        setFont(Estilo.fuente(Font.BOLD, 12f));
        setForeground(Estilo.TEXTO);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setMargin(new Insets(6, 8, 6, 8));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                encima = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                encima = false;
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.suavizar(g);
        g.setColor(getModel().isPressed() ? new Color(0xE6E6E6)
                : encima ? new Color(0xF1F1F1) : Color.WHITE);
        g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
        g.setColor(Estilo.LINEA);
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
        g.dispose();
        super.paintComponent(g0);
    }
}
