package vistas;

import modelos.Parada;
import modelos.PuntoInteres;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.OSMTileFactoryInfo;
import org.jxmapviewer.input.PanMouseInputListener;
import org.jxmapviewer.input.ZoomMouseWheelListenerCenter;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.TileFactoryInfo;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MouseInputListener;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntConsumer;

/**
 * Ventana principal. Disposición igual a la del diseño de referencia:
 * título "Mapa", panel izquierdo (rutas + lista numerada de paradas) y mapa a la derecha.
 */
public class MapaRutaVista extends JFrame {

    private static final GeoPosition CENTRO_MEDELLIN = new GeoPosition(6.2442, -75.5812);

    /** Datos de una ruta que la vista necesita para dibujarse. */
    public static class DatosRuta {
        public final String nombre;
        public final boolean visible;
        public final List<Parada> paradas;

        public DatosRuta(String nombre, boolean visible, List<Parada> paradas) {
            this.nombre = nombre;
            this.visible = visible;
            this.paradas = paradas;
        }
    }

    private JXMapViewer mapa;
    private final PintorRutas pintor = new PintorRutas();

    private final BotonRuta[] botonesRuta = new BotonRuta[3];
    private JPanel barraRuta;
    private JLabel lblNombreRuta;
    private Interruptor interruptorRuta;
    private JLabel lblResumen;

    private DefaultListModel<Parada> modeloParadas;
    private JList<Parada> listaParadas;
    private boolean actualizando = false;

    private BotonAccion btnAgregar, btnModificar, btnEliminar, btnGuardar, btnCargar, btnDistancia;

    private IntConsumer alCambiarRuta;
    private IntConsumer alSeleccionarParada;
    private Runnable alAlternarRuta;
    private int rutaActiva = 0;

    public MapaRutaVista() {
        super("Gestor de Rutas - Medellín");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 760);
        setMinimumSize(new Dimension(900, 560));
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        add(crearEncabezado(), BorderLayout.NORTH);
        add(crearPanelLateral(), BorderLayout.WEST);
        add(crearMapa(), BorderLayout.CENTER);
    }

    // ================= CONSTRUCCIÓN DE LA INTERFAZ =================

    private JComponent crearEncabezado() {
        JLabel titulo = new JLabel("Mapa");
        titulo.setFont(Estilo.fuente(Font.BOLD, 22f));
        titulo.setForeground(Estilo.TEXTO);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Estilo.FONDO_ENCABEZADO);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, Estilo.LINEA),
                new EmptyBorder(8, 14, 8, 14)));
        panel.add(titulo, BorderLayout.WEST);
        return panel;
    }

    private JComponent crearPanelLateral() {
        JPanel lateral = new JPanel(new BorderLayout());
        lateral.setBackground(Color.WHITE);
        lateral.setPreferredSize(new Dimension(310, 0));
        lateral.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Estilo.LINEA));

        lateral.add(crearParteSuperior(), BorderLayout.NORTH);
        lateral.add(crearListaParadas(), BorderLayout.CENTER);
        lateral.add(crearPanelAcciones(), BorderLayout.SOUTH);
        return lateral;
    }

    private JComponent crearParteSuperior() {
        JPanel superior = new JPanel();
        superior.setLayout(new BoxLayout(superior, BoxLayout.Y_AXIS));
        superior.setBackground(Color.WHITE);

        // "Ruta | Rutas"
        JLabel etiqueta = new JLabel("<html><b>Ruta</b> <font color='#BDBDBD'>|</font> Rutas</html>");
        etiqueta.setFont(Estilo.fuente(Font.PLAIN, 11.5f));
        etiqueta.setForeground(Estilo.ROJO_TITULO);
        etiqueta.setBorder(new EmptyBorder(8, 12, 2, 0));
        etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);
        superior.add(etiqueta);

        // Tres botones de bus: verde, azul y roja
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 4));
        fila.setBackground(Color.WHITE);
        fila.setAlignmentX(Component.LEFT_ALIGNMENT);
        for (int i = 0; i < 3; i++) {
            final int indice = i;
            botonesRuta[i] = new BotonRuta(Estilo.COLORES_RUTA[i],
                    "Ruta " + (i + 1) + " (" + Estilo.NOMBRES_COLOR[i] + ")",
                    () -> {
                        if (alCambiarRuta != null) alCambiarRuta.accept(indice);
                    });
            fila.add(botonesRuta[i]);
        }
        superior.add(fila);

        // Barra de color con el nombre de la ruta y su interruptor
        barraRuta = new JPanel(new BorderLayout());
        barraRuta.setBackground(Estilo.COLORES_RUTA[0]);
        barraRuta.setBorder(new EmptyBorder(0, 10, 0, 10));
        barraRuta.setPreferredSize(new Dimension(0, 34));
        barraRuta.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        barraRuta.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblNombreRuta = new JLabel("Ruta");
        lblNombreRuta.setFont(Estilo.fuente(Font.BOLD, 13f));
        lblNombreRuta.setForeground(Color.WHITE);
        barraRuta.add(lblNombreRuta, BorderLayout.CENTER);

        interruptorRuta = new Interruptor(() -> {
            if (alAlternarRuta != null) alAlternarRuta.run();
        });
        interruptorRuta.setToolTipText("Mostrar u ocultar esta ruta en el mapa");
        JPanel contenedorInterruptor = new JPanel(new GridBagLayout());
        contenedorInterruptor.setOpaque(false);
        contenedorInterruptor.add(interruptorRuta);
        barraRuta.add(contenedorInterruptor, BorderLayout.EAST);
        superior.add(barraRuta);
        return superior;
    }

    private JComponent crearListaParadas() {
        modeloParadas = new DefaultListModel<>();
        listaParadas = new JList<>(modeloParadas) {
            @Override
            public String getToolTipText(MouseEvent e) {
                int i = locationToIndex(e.getPoint());
                if (i < 0 || !getCellBounds(i, i).contains(e.getPoint())) return null;
                Parada p = modeloParadas.get(i);
                String desc = p.getDescripcion() == null || p.getDescripcion().isEmpty()
                        ? "(sin descripción)" : p.getDescripcion();
                return String.format("<html><b>%s</b><br>%s<br>Llegada: %s<br>Lat: %.5f  Lon: %.5f</html>",
                        p.getNombre(), desc, p.getHoraEstimada(), p.getLatitud(), p.getLongitud());
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (modeloParadas.isEmpty()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    Estilo.suavizar(g2);
                    g2.setFont(Estilo.fuente(Font.PLAIN, 12f));
                    g2.setColor(Estilo.TEXTO_SUAVE);
                    Estilo.textoCentrado(g2, "Esta ruta no tiene paradas", getWidth() / 2.0, 40);
                    Estilo.textoCentrado(g2, "Usa \"Agregar Parada\" o \"Cargar Ruta\"", getWidth() / 2.0, 60);
                    g2.dispose();
                }
            }
        };
        ToolTipManager.sharedInstance().registerComponent(listaParadas);
        listaParadas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaParadas.setFixedCellHeight(38);
        listaParadas.setCellRenderer(new RenderizadorParada());
        listaParadas.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || actualizando) return;
            pintor.setSeleccion(listaParadas.getSelectedIndex());
            mapa.repaint();
            if (alSeleccionarParada != null) alSeleccionarParada.accept(listaParadas.getSelectedIndex());
        });

        JScrollPane scroll = new JScrollPane(listaParadas);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        return scroll;
    }

    private JComponent crearPanelAcciones() {
        btnAgregar   = new BotonAccion("Agregar Parada");
        btnModificar = new BotonAccion("Modificar Parada");
        btnEliminar  = new BotonAccion("Eliminar Parada");
        btnGuardar   = new BotonAccion("Guardar Ruta");
        btnCargar    = new BotonAccion("Cargar Ruta");
        btnDistancia = new BotonAccion("Calcular Distancia");

        lblResumen = new JLabel(" ");
        lblResumen.setFont(Estilo.fuente(Font.PLAIN, 11.5f));
        lblResumen.setForeground(Estilo.TEXTO_SUAVE);
        lblResumen.setBorder(new EmptyBorder(0, 4, 6, 0));

        JPanel botones = new JPanel(new GridLayout(3, 2, 6, 6));
        botones.setOpaque(false);
        botones.add(btnAgregar);
        botones.add(btnModificar);
        botones.add(btnEliminar);
        botones.add(btnDistancia);
        botones.add(btnGuardar);
        botones.add(btnCargar);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Estilo.FONDO_ENCABEZADO);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Estilo.LINEA),
                new EmptyBorder(8, 8, 10, 8)));
        panel.add(lblResumen, BorderLayout.NORTH);
        panel.add(botones, BorderLayout.CENTER);
        return panel;
    }

    private JComponent crearMapa() {
        mapa = new JXMapViewer();

        // OpenStreetMap solo responde por HTTPS. El constructor por defecto de jxmapviewer2 2.6
        // usa http:// y Java no sigue esa redireccion a https://, por eso el mapa salia en blanco.
        TileFactoryInfo info = new OSMTileFactoryInfo("OpenStreetMap", "https://tile.openstreetmap.org");
        DefaultTileFactory fabricaTeselas = new DefaultTileFactory(info);
        fabricaTeselas.setThreadPoolSize(8);
        mapa.setTileFactory(fabricaTeselas);

        // Arrastrar para mover, rueda para hacer zoom
        MouseInputListener arrastre = new PanMouseInputListener(mapa);
        mapa.addMouseListener(arrastre);
        mapa.addMouseMotionListener(arrastre);
        mapa.addMouseWheelListener(new ZoomMouseWheelListenerCenter(mapa));

        // Clic sobre un marcador = seleccionar esa parada; el cursor cambia al pasar encima
        MouseAdapter interaccion = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() != MouseEvent.BUTTON1) return;
                int i = marcadorEn(e.getPoint());
                if (i >= 0) listaParadas.setSelectedIndex(i);
            }

            @Override
            public void mouseMoved(MouseEvent e) {
                int i = marcadorEn(e.getPoint());
                if (i >= 0) {
                    mapa.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                    mapa.setToolTipText(modeloParadas.get(i).getNombre());
                } else {
                    PuntoInteres poi = puntoInteresEn(e.getPoint());
                    mapa.setCursor(Cursor.getDefaultCursor());
                    mapa.setToolTipText(poi == null ? null : poi.getNombre());
                }
            }
        };
        mapa.addMouseListener(interaccion);
        mapa.addMouseMotionListener(interaccion);

        mapa.setOverlayPainter(pintor);
        pintor.setPuntos(PuntoInteres.catalogoMedellin());

        // Pestaña "Puntos de interés" en la esquina superior derecha
        mapa.setLayout(new BorderLayout());
        ChipPuntos chip = new ChipPuntos(() -> {
            pintor.setVerPuntos(!pintor.isVerPuntos());
            mapa.repaint();
        });
        JPanel esquina = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        esquina.setOpaque(false);
        esquina.add(chip);
        mapa.add(esquina, BorderLayout.NORTH);

        mapa.setZoom(5);
        mapa.setAddressLocation(CENTRO_MEDELLIN);
        return mapa;
    }

    // ================= CONEXIÓN CON EL CONTROLADOR =================

    public void setAlCambiarRuta(IntConsumer accion)          { this.alCambiarRuta = accion; }
    public void setAlSeleccionarParada(IntConsumer accion)    { this.alSeleccionarParada = accion; }
    public void setAlAlternarRuta(Runnable accion)            { this.alAlternarRuta = accion; }
    public void setAgregarParada(ActionListener evento)       { btnAgregar.addActionListener(evento); }
    public void setModificarParada(ActionListener evento)     { btnModificar.addActionListener(evento); }
    public void setEliminarParada(ActionListener evento)      { btnEliminar.addActionListener(evento); }
    public void setGuardarRuta(ActionListener evento)         { btnGuardar.addActionListener(evento); }
    public void setCargarRuta(ActionListener evento)          { btnCargar.addActionListener(evento); }
    public void setCalcularDistancia(ActionListener evento)   { btnDistancia.addActionListener(evento); }

    // ================= ACTUALIZAR LA PANTALLA =================

    /**
     * Redibuja todo con el estado actual: botones de ruta, barra, lista numerada y mapa.
     * @param indiceSeleccion parada a dejar seleccionada en la ruta activa (-1 = ninguna)
     */
    public void refrescar(List<DatosRuta> rutas, int activa, int indiceSeleccion) {
        this.rutaActiva = activa;
        actualizando = true;
        try {
            for (int i = 0; i < botonesRuta.length; i++) {
                botonesRuta[i].setActivo(i == activa);
            }
            Color color = Estilo.COLORES_RUTA[activa];
            DatosRuta datos = rutas.get(activa);

            barraRuta.setBackground(color);
            lblNombreRuta.setText(datos.nombre);
            interruptorRuta.setColorEncendido(color);
            interruptorRuta.setEncendido(datos.visible);
            lblResumen.setText(datos.paradas.size() + (datos.paradas.size() == 1 ? " parada" : " paradas")
                    + " en la ruta");

            modeloParadas.clear();
            for (Parada p : datos.paradas) modeloParadas.addElement(p);
            listaParadas.setSelectionBackground(mezclarConBlanco(color, 0.88f));
            listaParadas.setForeground(Estilo.TEXTO);
            if (indiceSeleccion >= 0 && indiceSeleccion < modeloParadas.size()) {
                listaParadas.setSelectedIndex(indiceSeleccion);
                listaParadas.ensureIndexIsVisible(indiceSeleccion);
            } else {
                listaParadas.clearSelection();
            }
            listaParadas.putClientProperty("colorRuta", color);

            List<PintorRutas.RutaDibujo> dibujos = new ArrayList<>();
            for (int r = 0; r < rutas.size(); r++) {
                List<Marcador> marcadores = new ArrayList<>();
                int n = 1;
                for (Parada p : rutas.get(r).paradas) {
                    marcadores.add(new Marcador(new GeoPosition(p.getLatitud(), p.getLongitud()),
                            n++, p.getNombre(), Estilo.COLORES_RUTA[r]));
                }
                dibujos.add(new PintorRutas.RutaDibujo(Estilo.COLORES_RUTA[r], rutas.get(r).visible, marcadores));
            }
            pintor.setRutas(dibujos, activa, listaParadas.getSelectedIndex());
        } finally {
            actualizando = false;
        }
        listaParadas.repaint();
        mapa.repaint();
    }

    /** Índice de la parada seleccionada en la lista (-1 si no hay ninguna) */
    public int getIndiceSeleccionado() {
        return listaParadas.getSelectedIndex();
    }

    // ================= MAPA =================

    /** Centra el mapa en unas coordenadas */
    public void setUbicacionMapa(double latitud, double longitud) {
        mapa.setAddressLocation(new GeoPosition(latitud, longitud));
    }

    /** Ajusta el zoom para que se vean todas las paradas indicadas */
    public void ajustarMapa(List<Parada> paradas) {
        if (paradas.isEmpty()) return;
        if (mapa.getWidth() == 0 || mapa.getHeight() == 0) {
            // La ventana todavía no se ha dibujado: se espera a que el mapa tenga tamaño
            mapa.addComponentListener(new java.awt.event.ComponentAdapter() {
                @Override
                public void componentResized(java.awt.event.ComponentEvent e) {
                    if (mapa.getWidth() > 0 && mapa.getHeight() > 0) {
                        mapa.removeComponentListener(this);
                        ajustarMapa(paradas);
                    }
                }
            });
            return;
        }
        if (paradas.size() == 1) {
            setUbicacionMapa(paradas.get(0).getLatitud(), paradas.get(0).getLongitud());
            return;
        }
        Set<GeoPosition> posiciones = new HashSet<>();
        for (Parada p : paradas) posiciones.add(new GeoPosition(p.getLatitud(), p.getLongitud()));
        mapa.zoomToBestFit(posiciones, 0.8);
    }

    // ================= BÚSQUEDA DE ELEMENTOS BAJO EL MOUSE =================

    private int marcadorEn(Point punto) {
        for (int i = modeloParadas.size() - 1; i >= 0; i--) {
            Parada p = modeloParadas.get(i);
            Point2D pos = PintorRutas.aPantalla(mapa, new GeoPosition(p.getLatitud(), p.getLongitud()));
            if (pos.distance(punto) <= 13) return i;
        }
        return -1;
    }

    private PuntoInteres puntoInteresEn(Point punto) {
        if (!pintor.isVerPuntos()) return null;
        for (PuntoInteres poi : pintor.getPuntos()) {
            Point2D pos = PintorRutas.aPantalla(mapa, new GeoPosition(poi.getLatitud(), poi.getLongitud()));
            // La punta del pin está en pos; el cuerpo se dibuja hacia arriba
            if (Math.abs(punto.x - pos.getX()) <= 9 && punto.y <= pos.getY() + 2 && punto.y >= pos.getY() - 26) {
                return poi;
            }
        }
        return null;
    }

    private static Color mezclarConBlanco(Color c, float fraccionBlanco) {
        int r = (int) (c.getRed() + (255 - c.getRed()) * fraccionBlanco);
        int g = (int) (c.getGreen() + (255 - c.getGreen()) * fraccionBlanco);
        int b = (int) (c.getBlue() + (255 - c.getBlue()) * fraccionBlanco);
        return new Color(r, g, b);
    }

    // ================= FILA DE LA LISTA =================

    /** Cada fila: círculo de color con el número, nombre en mayúsculas y línea inferior. */
    private class RenderizadorParada extends JComponent implements ListCellRenderer<Parada> {
        private int numero;
        private String texto = "";
        private boolean seleccionada;
        private Color colorFondoSel = Color.WHITE;
        private Color colorRuta = Estilo.COLORES_RUTA[0];

        @Override
        public Component getListCellRendererComponent(JList<? extends Parada> lista, Parada valor,
                                                      int indice, boolean sel, boolean foco) {
            numero = indice + 1;
            texto = valor.getNombre().toUpperCase();
            seleccionada = sel;
            colorFondoSel = lista.getSelectionBackground();
            colorRuta = Estilo.COLORES_RUTA[rutaActiva];
            return this;
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(100, 38);
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Estilo.suavizar(g);
            int w = getWidth(), h = getHeight();

            g.setColor(seleccionada ? colorFondoSel : Color.WHITE);
            g.fillRect(0, 0, w, h);
            g.setColor(Estilo.LINEA);
            g.drawLine(10, h - 1, w - 10, h - 1);

            // Círculo numerado
            int d = 22;
            g.setColor(colorRuta);
            g.fillOval(12, (h - d) / 2, d, d);
            g.setColor(Color.WHITE);
            g.setFont(Estilo.fuente(Font.BOLD, 11.5f));
            Estilo.textoCentrado(g, String.valueOf(numero), 12 + d / 2.0, h / 2.0);

            // Nombre (se recorta con "…" si no cabe)
            g.setFont(Estilo.fuente(Font.BOLD, 12f));
            g.setColor(Estilo.TEXTO);
            FontMetrics fm = g.getFontMetrics();
            String t = texto;
            int maximo = w - 52 - 10;
            while (fm.stringWidth(t) > maximo && t.length() > 1) {
                t = t.substring(0, t.length() - 1);
                if (fm.stringWidth(t + "…") <= maximo) { t = t + "…"; break; }
            }
            g.drawString(t, 46, (h + fm.getAscent() - fm.getDescent()) / 2);
            g.dispose();
        }
    }
}
