package vistas;

import java.awt.*;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;

/** Colores, fuentes y dibujos compartidos por toda la interfaz. */
public final class Estilo {

    /** Ruta 1 verde, ruta 2 azul, ruta 3 roja (como en el diseño de referencia). */
    public static final Color[] COLORES_RUTA = {
            new Color(0x1CD34A), new Color(0x1A1AB0), new Color(0xE01414)
    };
    public static final String[] NOMBRES_COLOR = {"verde", "azul", "roja"};

    public static final Color ROJO_TITULO = new Color(0xD32F2F);
    public static final Color AMARILLO    = new Color(0xF5A300);
    public static final Color TEXTO       = new Color(0x404040);
    public static final Color TEXTO_SUAVE = new Color(0x8A8A8A);
    public static final Color LINEA       = new Color(0xE2E2E2);
    public static final Color FONDO_ENCABEZADO = new Color(0xF7F7F7);

    private Estilo() {
    }

    public static Font fuente(int estilo, float tamanio) {
        return new Font(Font.SANS_SERIF, estilo, 12).deriveFont(estilo, tamanio);
    }

    public static void suavizar(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    /** Dibuja un pin (gota) cuya punta está en (x, y). */
    public static void dibujarPin(Graphics2D g, double x, double y, double alto, Color color) {
        double r = alto * 0.36;
        double cy = y - alto + r;
        Area gota = new Area(new Ellipse2D.Double(x - r, cy - r, 2 * r, 2 * r));
        Path2D.Double triangulo = new Path2D.Double();
        triangulo.moveTo(x - r * 0.86, cy + r * 0.5);
        triangulo.lineTo(x + r * 0.86, cy + r * 0.5);
        triangulo.lineTo(x, y);
        triangulo.closePath();
        gota.add(new Area(triangulo));

        g.setColor(color);
        g.fill(gota);
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(1.2f));
        g.draw(gota);
        g.fill(new Ellipse2D.Double(x - r * 0.4, cy - r * 0.4, r * 0.8, r * 0.8));
    }

    /** Dibuja texto centrado en un rectángulo. */
    public static void textoCentrado(Graphics2D g, String texto, double cx, double cy) {
        FontMetrics fm = g.getFontMetrics();
        float x = (float) (cx - fm.stringWidth(texto) / 2.0);
        float y = (float) (cy + (fm.getAscent() - fm.getDescent()) / 2.0);
        g.drawString(texto, x, y);
    }
}
