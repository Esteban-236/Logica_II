import controladores.MapaRutaControlador;
import vistas.MapaRutaVista;

import javax.swing.*;

public class App {

    public static void main(String[] args) {
        // Los servidores de mapas de OpenStreetMap piden identificar la aplicación
        System.setProperty("http.agent", "RutasMedellin/1.0 (proyecto academico)");

        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignorada) {
                // Si falla, se usa el aspecto por defecto de Swing
            }

            MapaRutaVista vista = new MapaRutaVista();
            new MapaRutaControlador(vista);
            vista.setVisible(true);
        });
    }
}
