package controladores;

import com.fasterxml.jackson.core.type.TypeReference;
import modelos.ListaParadas;
import modelos.Parada;
import modelos.RutaArchivo;
import servicios.ArchivoServicio;
import vistas.FormularioParada;
import vistas.MapaRutaVista;
import vistas.MapaRutaVista.DatosRuta;

import javax.swing.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Lógica de la aplicación. Maneja tres rutas (verde, azul y roja); cada una es una
 * lista ligada de paradas. Las operaciones actúan sobre la ruta activa.
 */
public class MapaRutaControlador {

    private static final int NUMERO_RUTAS = 3;
    /** Archivos que se cargan al iniciar: Ruta Medellín 1, 2 y 3 (una por botón). */
    private static final String[] RUTAS_INICIALES = {
            "rutas/ruta_medellin_1.json",
            "rutas/ruta_medellin_2.json",
            "rutas/ruta_medellin_3.json"
    };
    /** Respaldo para la ruta 1 si no existe ruta_medellin_1.json. */
    private static final String RUTA_EJEMPLO = "rutas/ruta_ejemplo.json";

    private final MapaRutaVista vista;
    private final ListaParadas[] rutas = new ListaParadas[NUMERO_RUTAS];
    private final boolean[] visibles = {true, true, true};
    private int activa = 0;

    public MapaRutaControlador(MapaRutaVista vista) {
        this.vista = vista;
        rutas[0] = new ListaParadas("Ruta Medellín 1");
        rutas[1] = new ListaParadas("Ruta Medellín 2");
        rutas[2] = new ListaParadas("Ruta Medellín 3");

        vista.setAlCambiarRuta(this::cambiarRuta);
        vista.setAlSeleccionarParada(this::alSeleccionarParada);
        vista.setAlAlternarRuta(this::alternarVisibilidad);
        vista.setAgregarParada(e -> agregarParada());
        vista.setModificarParada(e -> modificarParada());
        vista.setEliminarParada(e -> eliminarParada());
        vista.setGuardarRuta(e -> guardarRuta());
        vista.setCargarRuta(e -> cargarRuta());
        vista.setCalcularDistancia(e -> calcularDistancia());

        cargarRutasIniciales();
        actualizarVista(-1);
        vista.ajustarMapa(rutas[activa].aLista());
    }

    /** Carga las tres rutas de la carpeta rutas/ para poder compararlas desde el inicio. */
    private void cargarRutasIniciales() {
        for (int i = 0; i < NUMERO_RUTAS; i++) {
            String archivo = RUTAS_INICIALES[i];
            if (i == 0 && !new File(archivo).isFile()) {
                archivo = RUTA_EJEMPLO;
            }
            if (!new File(archivo).isFile()) continue;

            RutaArchivo datos = ArchivoServicio.leerJson(archivo, new TypeReference<RutaArchivo>() {});
            if (datos != null) {
                rutas[i] = ListaParadas.desdeRutaArchivo(datos);
            }
        }
    }

    // ================= RUTAS =================

    private void cambiarRuta(int indice) {
        if (indice == activa) return;
        activa = indice;
        actualizarVista(-1);
        vista.ajustarMapa(rutas[activa].aLista());
    }

    private void alternarVisibilidad() {
        visibles[activa] = !visibles[activa];
        actualizarVista(vista.getIndiceSeleccionado());
    }

    // ================= ACCIONES DE LOS BOTONES =================

    private void agregarParada() {
        Parada nueva = FormularioParada.mostrar(vista, null);
        if (nueva == null) return;

        visibles[activa] = true;
        rutas[activa].agregar(nueva);
        actualizarVista(rutas[activa].size() - 1);
    }

    private void modificarParada() {
        int idx = vista.getIndiceSeleccionado();
        if (idx < 0) {
            mostrarAdvertencia("Selecciona primero una parada de la lista.");
            return;
        }

        Parada editada = FormularioParada.mostrar(vista, rutas[activa].obtener(idx));
        if (editada == null) return;

        rutas[activa].modificar(idx, editada);
        actualizarVista(idx);
    }

    private void eliminarParada() {
        int idx = vista.getIndiceSeleccionado();
        if (idx < 0) {
            mostrarAdvertencia("Selecciona primero una parada de la lista.");
            return;
        }

        String nombre = rutas[activa].obtener(idx).getNombre();
        int op = JOptionPane.showConfirmDialog(vista,
                "¿Eliminar la parada \"" + nombre + "\"?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
        if (op == JOptionPane.YES_OPTION) {
            rutas[activa].eliminar(idx);
            actualizarVista(-1);
        }
    }

    private void guardarRuta() {
        if (rutas[activa].estaVacia()) {
            mostrarAdvertencia("No hay paradas para guardar.");
            return;
        }

        String archivo = ArchivoServicio.elegirArchivo(true);
        if (archivo.isEmpty()) return;
        if (!archivo.toLowerCase().endsWith(".json")) {
            archivo += ".json";
        }

        if (ArchivoServicio.guardarJson(archivo, rutas[activa].toRutaArchivo())) {
            mostrarMensaje("Ruta guardada correctamente en:\n" + archivo);
        } else {
            mostrarError("No se pudo guardar la ruta.");
        }
    }

    private void cargarRuta() {
        String archivo = ArchivoServicio.elegirArchivo(false);
        if (archivo.isEmpty()) return;

        RutaArchivo datos = ArchivoServicio.leerJson(archivo, new TypeReference<RutaArchivo>() {});
        if (datos == null) {
            mostrarError("No se pudo leer el archivo JSON seleccionado.");
            return;
        }

        rutas[activa] = ListaParadas.desdeRutaArchivo(datos);
        visibles[activa] = true;
        actualizarVista(-1);
        vista.ajustarMapa(rutas[activa].aLista());
        mostrarMensaje("Ruta cargada: " + rutas[activa].getNombreRuta()
                + " (" + rutas[activa].size() + " paradas)");
    }

    private void calcularDistancia() {
        if (rutas[activa].size() < 2) {
            mostrarAdvertencia("Se necesitan al menos 2 paradas para calcular la distancia.");
            return;
        }
        mostrarMensaje(String.format(
                "Distancia total aproximada de la ruta: %.2f km",
                rutas[activa].calcularDistanciaTotalKm()));
    }

    // ================= SELECCIÓN =================

    /** Se ejecuta al elegir una parada (en la lista o sobre el mapa): el mapa se centra en ella */
    private void alSeleccionarParada(int idx) {
        if (idx >= 0 && idx < rutas[activa].size()) {
            Parada p = rutas[activa].obtener(idx);
            vista.setUbicacionMapa(p.getLatitud(), p.getLongitud());
        }
    }

    // ================= REFRESCAR LA VISTA =================

    /** Vuelve a dibujar la lista numerada y el mapa con el estado actual de las listas ligadas */
    private void actualizarVista(int indiceSeleccion) {
        List<DatosRuta> datos = new ArrayList<>();
        for (int i = 0; i < NUMERO_RUTAS; i++) {
            datos.add(new DatosRuta(rutas[i].getNombreRuta(), visibles[i], rutas[i].aLista()));
        }
        vista.refrescar(datos, activa, indiceSeleccion);
        if (indiceSeleccion >= 0) {
            alSeleccionarParada(indiceSeleccion);
        }
    }

    // ================= MENSAJES =================

    private void mostrarMensaje(String texto) {
        JOptionPane.showMessageDialog(vista, texto, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarAdvertencia(String texto) {
        JOptionPane.showMessageDialog(vista, texto, "Atención", JOptionPane.WARNING_MESSAGE);
    }

    private void mostrarError(String texto) {
        JOptionPane.showMessageDialog(vista, texto, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
